# Wiring Guide

## WS2812 LED strip

- Strip `DIN` → Arduino Uno `D6` (a 330–470 Ω series resistor is recommended).
- Strip `+5V` → regulated 5 V boost converter output.
- Strip `GND` → boost converter GND.
- Arduino `GND` → same common GND as the strip and boost converter.

## Buzzer

- Buzzer signal / `+` → Arduino `D9` (for a module with a signal input).
- Buzzer `-` / GND → Arduino GND.
- If using a bare buzzer that draws more current than an Arduino pin can safely provide, use a transistor driver.

## Battery and charging

Follow the labels and datasheet for the exact TP4056 board and boost converter. A typical single-cell arrangement is battery → TP4056 B+/B-; protected battery output or board output → boost converter input; boost converter output adjusted and verified to 5 V → project 5 V rail.

Do not assume every TP4056 board has battery protection. Do not connect a raw battery to the 5 V rail. Do not connect a regulated 5 V supply to Arduino VIN; if powering through the 5V pin, ensure it is a clean, regulated 5 V and that the USB cable is not simultaneously powering the board in a conflicting setup.

## Power notes

WS2812 LEDs can draw substantial current, especially at high brightness and full white. This sketch limits brightness to 45/255, but the supply must still be appropriately rated. Use adequate wire gauge, a common ground, and a bulk capacitor near the strip. Verify polarity and voltage with a multimeter before connecting.
