# Add your project photos

Add genuine photos of your assembled prototype, wiring, and working LED sequence to this folder. Do not use placeholder or internet images as evidence of your own build.
