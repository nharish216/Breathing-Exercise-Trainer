# Working Principle

The Arduino Uno runs a repeating four-stage breathing cycle. The WS2812 LED strip receives digital color data through its data input.

1. **Inhale:** Green LEDs progressively illuminate from the beginning of the strip.
2. **Hold after inhale:** The full strip displays blue.
3. **Exhale:** Red LEDs progressively turn off, visually indicating a gradual exhale.
4. **Rest after exhale:** The full strip displays blue until the next cycle begins.

Each stage lasts seven seconds by default. At the beginning of each stage, the buzzer gives two short beeps. The cycle repeats continuously.

The timing is configurable in the Arduino sketch. The light pattern is a visual guide only; users should breathe comfortably and should not force a particular breathing rate.
