# Testing Checklist

Complete this checklist on the physical prototype and replace the notes with your actual observations.

- [ ] Confirm boost converter output is regulated to 5 V before connecting the strip.
- [ ] Confirm all grounds are connected together.
- [ ] Upload the sketch successfully to Arduino Uno.
- [ ] Confirm green inhale animation runs.
- [ ] Confirm blue hold stage runs.
- [ ] Confirm red exhale animation runs.
- [ ] Confirm blue rest stage runs.
- [ ] Confirm buzzer beeps at each stage transition.
- [ ] Run multiple cycles and check for resets, flicker, or overheating.
- [ ] Test battery runtime and charging behavior safely.
- [ ] Record actual test results, photos, and any corrections here.

Do not mark a test as passed until you have performed it on your own hardware.
