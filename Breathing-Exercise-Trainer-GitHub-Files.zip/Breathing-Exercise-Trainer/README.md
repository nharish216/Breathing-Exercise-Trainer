# Breathing Exercise Trainer using WS2812 LED Strip

An Arduino Uno-based breathing guide that uses a WS2812 addressable RGB LED strip to visually guide a user through four stages:

1. **Inhale** – green LEDs gradually illuminate.
2. **Hold** – blue LEDs remain illuminated.
3. **Exhale** – red LEDs gradually fade.
4. **Rest** – blue LEDs indicate the pause before the next cycle.

A buzzer provides simple audio beeps at stage transitions.

> **Project note:** The listed hardware includes a buzzer, not a voice playback module. Therefore, this version provides buzzer alerts only. Spoken prompts such as “inhale” and “exhale” require an additional audio playback module and speaker, or a phone-based audio solution.

## Hardware

- Arduino Uno
- WS2812B / WS2812 addressable LED strip (28 LEDs in this configuration)
- Active buzzer (or compatible buzzer module)
- 18650 Li-ion cell and suitable holder
- TP4056 charging module (preferably the protected version)
- 5 V boost converter capable of supplying the LED current
- On/off switch
- USB cable for programming

## Pin connections

| Component | Arduino / power connection |
|---|---|
| WS2812 DIN | Digital pin 6 (through a 330–470 Ω series resistor recommended) |
| WS2812 +5V | Regulated 5 V boost output |
| WS2812 GND | Common GND |
| Buzzer signal | Digital pin 9 |
| Buzzer GND | GND |
| Arduino | Regulated 5 V to 5V pin only when the supply is a stable, regulated 5 V |

**Important:** Connect the LED power supply ground and Arduino ground together. Do not power a long/high-current LED strip from the Arduino 5 V pin. Add a suitably rated bulk capacitor (for example, 1000 µF, 6.3 V or higher) across LED 5 V and GND near the strip. Keep the boost converter output at 5 V. Check the exact buzzer module polarity and voltage rating.

## Software setup

1. Install the Arduino IDE.
2. In Arduino IDE, open **Library Manager**.
3. Search for and install **Adafruit NeoPixel**.
4. Open `src/breathing_exercise_trainer.ino`.
5. Select **Arduino Uno** and the correct COM port.
6. Upload the sketch.

## Default settings

- LED data pin: `6`
- Buzzer pin: `9`
- LED count: `28`
- Stage duration: `7 seconds`
- Animation steps: `7`

Change `STAGE_TIME_MS`, `NUM_LEDS`, or the pin constants near the top of the sketch to suit your hardware.

## Repository contents

- `src/` – Arduino source code
- `docs/` – wiring, operation, and component documentation
- `images/` – add your own prototype and circuit photographs here

## Safety

- Use a genuine, undamaged 18650 cell and a charger/protection arrangement suitable for that cell.
- Never connect the raw 18650 cell directly to the Arduino 5V pin or WS2812 5V input.
- Verify the boost converter output with a multimeter before connecting electronics.
- Ensure the boost converter and wiring can handle the LED current. Limit LED brightness in software.
- Disconnect the battery before changing wiring.
- This is a general wellness/educational prototype, not a medical device. Stop using it if you feel dizzy, uncomfortable, or short of breath. Breathe normally and do not force breath-holding.

## Project status

Prototype firmware and documentation. Add real photographs, your final circuit diagram, test results, and any changes made to the hardware before presenting this repository as a completed build.
