# Components List

| No. | Component | Purpose |
|---:|---|---|
| 1 | Arduino Uno | Controls the breathing sequence and LED strip |
| 2 | WS2812 LED strip (28 LEDs) | Visual breathing-stage indication |
| 3 | Buzzer | Audio beep at stage transitions |
| 4 | 18650 Li-ion cell | Portable power source |
| 5 | Battery holder | Holds the 18650 cell |
| 6 | TP4056 charging module | Charges the single-cell Li-ion battery; use a protected module where appropriate |
| 7 | 5 V boost converter | Converts battery voltage to regulated 5 V |
| 8 | On/off switch | Main power control |
| 9 | USB cable | Uploads firmware to Arduino Uno |

Check the current ratings and wiring of the exact modules purchased. The boost converter must be sized for the LED load, and the battery/charger/protection circuit must be appropriate for the cell.
