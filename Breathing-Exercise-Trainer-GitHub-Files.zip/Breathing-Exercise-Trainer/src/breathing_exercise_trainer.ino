/*
  Breathing Exercise Trainer using WS2812 LED Strip
  Board: Arduino Uno
  LED data: D6
  Buzzer: D9
  LED count: 28

  Install the "Adafruit NeoPixel" library from Arduino IDE Library Manager.
  This firmware uses buzzer beeps. Spoken voice prompts need extra audio hardware.
*/

#include <Adafruit_NeoPixel.h>

#define LED_PIN       6
#define BUZZER_PIN    9
#define NUM_LEDS      28

// Seven seconds per stage; adjust to your preferred breathing pace.
const unsigned long STAGE_TIME_MS = 7000UL;
const byte ANIMATION_STEPS = 7;

// Keep brightness low to reduce power consumption.
const byte LED_BRIGHTNESS = 45;

Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

enum Stage {
  INHALE,
  HOLD_AFTER_INHALE,
  EXHALE,
  REST_AFTER_EXHALE
};

Stage currentStage = INHALE;
unsigned long stageStartedAt = 0;
byte lastBeepedStage = 255;

uint32_t greenColor;
uint32_t blueColor;
uint32_t redColor;

void beepStageStart() {
  // Two short beeps at the beginning of each stage.
  tone(BUZZER_PIN, 1800, 100);
  delay(140);
  tone(BUZZER_PIN, 1800, 100);
}

void clearStrip() {
  strip.clear();
  strip.show();
}

void showProgressColor(uint32_t color, byte litCount) {
  strip.clear();
  for (byte i = 0; i < litCount && i < NUM_LEDS; i++) {
    strip.setPixelColor(i, color);
  }
  strip.show();
}

void animateInhale(float progress) {
  // Green bar grows as the user inhales.
  byte litCount = (byte)(progress * NUM_LEDS);
  if (progress > 0.0 && litCount == 0) litCount = 1;
  showProgressColor(greenColor, litCount);
}

void animateHold() {
  // Blue indicates holding/pause.
  strip.fill(blueColor, 0, NUM_LEDS);
  strip.show();
}

void animateExhale(float progress) {
  // Red bar shrinks as the user exhales.
  byte litCount = (byte)((1.0 - progress) * NUM_LEDS);
  showProgressColor(redColor, litCount);
}

void startStage(Stage nextStage) {
  currentStage = nextStage;
  stageStartedAt = millis();
  beepStageStart();
}

void setup() {
  pinMode(BUZZER_PIN, OUTPUT);

  strip.begin();
  strip.setBrightness(LED_BRIGHTNESS);
  strip.show();

  greenColor = strip.Color(0, 150, 0);
  blueColor  = strip.Color(0, 0, 150);
  redColor   = strip.Color(150, 0, 0);

  startStage(INHALE);
}

void loop() {
  unsigned long elapsed = millis() - stageStartedAt;
  float progress = (float)elapsed / (float)STAGE_TIME_MS;

  if (progress > 1.0) progress = 1.0;

  switch (currentStage) {
    case INHALE:
      animateInhale(progress);
      if (elapsed >= STAGE_TIME_MS) startStage(HOLD_AFTER_INHALE);
      break;

    case HOLD_AFTER_INHALE:
      animateHold();
      if (elapsed >= STAGE_TIME_MS) startStage(EXHALE);
      break;

    case EXHALE:
      animateExhale(progress);
      if (elapsed >= STAGE_TIME_MS) startStage(REST_AFTER_EXHALE);
      break;

    case REST_AFTER_EXHALE:
      animateHold();
      if (elapsed >= STAGE_TIME_MS) startStage(INHALE);
      break;
  }

  delay(20); // Smooth visual updates without excessive refreshes.
}
